#define CONFIG_KILL 1
