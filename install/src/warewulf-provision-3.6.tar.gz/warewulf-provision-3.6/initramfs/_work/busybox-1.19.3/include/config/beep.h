#define CONFIG_BEEP 1
